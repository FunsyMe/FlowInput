﻿$host.UI.RawUI.WindowTitle = "О приложении"

# Check Admin
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())

if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "[ОШИБКА] Запустите от имени администратора" -ForegroundColor Red
    Write-Host "Нажмите любую кнопку для выхода..."
    [void][System.Console]::ReadKey($true)

    Start-Process $ninjaService -NoNewWindow
    exit
}

# Dir Variables
$rootDir = Split-Path $PSScriptRoot -Parent
$ninjaService = Join-Path $rootDir "ninja_service.bat"
$versionFile = Join-Path $rootDir "bin/ninja_version.txt"

# Write Info
$appVersion = Get-Content -Path $versionFile -TotalCount 1
Write-Host "[ИНФО] Ninja Service v$appVersion, by Funsy" -ForegroundColor Cyan
Write-Host "[ИНФО] 2026, Funsy. Все права защищены" -ForegroundColor Cyan
Write-Host
Write-Host "Нажмите любую клавишу для выхода..."
[void][System.Console]::ReadKey($true)
    
Start-Process $ninjaService -NoNewWindow
exit